function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5zjUPNT7v3n":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

