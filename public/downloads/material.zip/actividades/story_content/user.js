function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5jyTOKq8yrv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

